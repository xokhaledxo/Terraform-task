import os
import pymysql

def lambda_handler(event, context):
    db_host = os.environ['DB_HOST']
    db_username = os.environ['DB_USERNAME']
    db_password = os.environ['DB_PASSWORD']
    db_name = os.environ['DB_NAME']
    
    connection = pymysql.connect(
        host=db_host,
        user=db_username,
        password=db_password,
        database=db_name
    )
    
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT NOW()")
            result = cursor.fetchone()
            print("Current time: ", result)
    finally:
        connection.close()
    
    return {
        'statusCode': 200,
        'body': 'Connected to RDS and retrieved current time: {}'.format(result)
    }
